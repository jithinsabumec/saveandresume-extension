'use strict';

(() => {
    const config = Object.freeze({
    "firebase": {
        "apiKey": "AIzaSyDeuZ1sGr660AF-F_jqpdRKGapUT1Dpzzs",
        "authDomain": "save-and-resume.firebaseapp.com",
        "projectId": "save-and-resume",
        "storageBucket": "save-and-resume.firebasestorage.app",
        "messagingSenderId": "169747525486",
        "appId": "1:169747525486:web:c13b6c68c8e1d6aa1d9b7f",
        "measurementId": "G-LR2Q1RK63T"
    }
});
    globalThis.__SAVE_RESUME_CONFIG__ = config;
})();
